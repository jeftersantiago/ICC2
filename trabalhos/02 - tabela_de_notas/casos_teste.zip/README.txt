Arquivo zip gerado em: 31/10/2022 12:23:04 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Prático 2 - Tabela de notas