#ifndef _Util_
#define _Util_

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define true 1
#define false 0
#define boolean int



#endif

