#ifndef _search_
#define _search_
#include "catalogue.h"
void search(Wine **list, double key, int property, int size);
#endif
